"use client"

import { useState } from 'react'
import Image from 'next/image'
import { DimensionContent } from './components/DimensionContent'
import { NavigationButton } from './components/NavigationButton'
import './minecraft-ui.css'
const dimensions = [
  {
    id: 'overworld',
    title: '主世界',
    description: '欢迎来到主世界，Minecraft的主要维度。这个充满生机和多样化的世界，资源丰富，充满了冒险与创造的无限可能。',
    backgroundImage: '/overworld.jpeg'
  },
  {
    id: 'end',
    title: '末地',
    description: '欢迎来到末地，一个神秘且充满挑战的维度。这个虚幻的世界是强大的末影龙的栖息地，隐藏着巨大的秘密和强大的力量。',
    backgroundImage: '/end.jpg'
  },
  {
    id: 'nether',
    title: '地狱',
    description: '欢迎来到地狱，一个充满火焰和硫磺的恶劣维度。这个危险的世界充满了独特的资源和可怕的生物。',
    backgroundImage: '/nether.jpg'
  }
]


export default function Home() {
  const [currentPage, setCurrentPage] = useState(0)
  
  const nextPage = () => {
    setCurrentPage((prev) => (prev + 1) % dimensions.length)
  }
  
  const prevPage = () => {
    setCurrentPage((prev) => (prev - 1 + dimensions.length) % dimensions.length)
  }

  const currentDimension = dimensions[currentPage]

  return (
    <main className="minecraft-container">
      <div className={`dimension-content ${currentDimension.id}`}>
        <Image
          src={currentDimension.backgroundImage}
          alt={`${currentDimension.title} background`}
          layout="fill"
          objectFit="cover"
          quality={100}
        />
        <div className="dimension-overlay"></div>
        <DimensionContent dimension={currentDimension} />
        <NavigationButton direction="left" onClick={prevPage} />
        <NavigationButton direction="right" onClick={nextPage} />
      </div>
    </main>
  )
}

