interface NavigationButtonProps {
  direction: 'left' | 'right';
  onClick: () => void;
}

export function NavigationButton({ direction, onClick }: NavigationButtonProps) {
  return (
    <button 
      onClick={onClick}
      className={`minecraft-nav-button ${direction}`}
      aria-label={`${direction === 'left' ? 'Previous' : 'Next'} dimension`}
    >
      {direction === 'left' ? '<' : '>'}
    </button>
  )
}

