import { ActionButton } from './ActionButton'

interface DimensionContentProps {
  dimension: {
    title: string;
    description: string;
  }
}

export function DimensionContent({ dimension }: DimensionContentProps) {
  return (
    <div className="dimension-text">
      <h1 className="dimension-title">{dimension.title}</h1>
      <p className="dimension-description">{dimension.description}</p>
      <div className="button-container">
        <ActionButton>前往 {dimension.title}</ActionButton>
      </div>
    </div>
  )
}

