interface ActionButtonProps {
  children: React.ReactNode;
  onClick?: () => void;
}

export function ActionButton({ children, onClick }: ActionButtonProps) {
  return (
    <button className="minecraft-button" onClick={onClick}>
      {children}
    </button>
  )
}

